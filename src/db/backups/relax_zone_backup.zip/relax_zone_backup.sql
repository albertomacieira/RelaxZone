﻿/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-12.0.2-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: relax_zone
-- ------------------------------------------------------
-- Server version	12.0.2-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `bookings`
--

DROP TABLE IF EXISTS `bookings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `bookings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `start_at` datetime NOT NULL,
  `end_at` datetime NOT NULL,
  `status` enum('PENDING','APPROVED','CANCELLED') NOT NULL DEFAULT 'PENDING',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_booking_service` (`service_id`),
  KEY `idx_booking_user` (`user_id`),
  KEY `idx_booking_time` (`start_at`,`end_at`),
  KEY `idx_booking_status` (`status`),
  CONSTRAINT `fk_booking_service` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`),
  CONSTRAINT `fk_booking_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bookings`
--

LOCK TABLES `bookings` WRITE;
/*!40000 ALTER TABLE `bookings` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `bookings` VALUES
(1,1,1,'2026-01-12 10:00:00','2026-01-12 11:00:00','APPROVED','2026-01-11 18:47:52'),
(2,1,1,'2026-01-12 10:00:00','2026-01-12 11:00:00','CANCELLED','2026-01-11 18:55:11'),
(3,1,3,'2026-01-12 11:00:00','2026-01-12 11:50:00','PENDING','2026-01-11 21:55:35'),
(4,1,1,'2026-01-14 10:00:00','2026-01-14 11:00:00','PENDING','2026-01-11 22:01:29'),
(5,1,1,'2026-01-12 00:19:00','2026-01-12 01:19:00','PENDING','2026-01-11 22:19:16'),
(6,1,1,'2026-01-12 22:30:00','2026-01-12 23:30:00','PENDING','2026-01-11 22:20:17'),
(7,3,1,'2026-01-12 15:00:00','2026-01-12 16:00:00','APPROVED','2026-01-11 23:27:14'),
(8,3,2,'2026-01-20 12:00:00','2026-01-20 12:45:00','APPROVED','2026-01-13 14:37:40'),
(9,3,1,'2026-01-16 16:30:00','2026-01-16 17:30:00','PENDING','2026-01-13 15:26:53'),
(10,3,1,'2026-01-15 13:00:00','2026-01-15 14:00:00','PENDING','2026-01-13 19:04:55'),
(11,4,1,'2026-01-15 13:00:00','2026-01-15 14:00:00','APPROVED','2026-01-13 19:05:34');
/*!40000 ALTER TABLE `bookings` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `services`
--

DROP TABLE IF EXISTS `services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL,
  `description` text DEFAULT NULL,
  `duration_min` int(11) NOT NULL,
  `price_cents` int(11) NOT NULL,
  `image_url` varchar(500) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `services`
--

LOCK TABLES `services` WRITE;
/*!40000 ALTER TABLE `services` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `services` VALUES
(1,'Massagem Relaxante','Massagem corporal para al├¡vio de tens├úo.',60,4500,'',1,'2026-01-11 14:28:17'),
(2,'Aromaterapia','Sess├úo com ├│leos essenciais.',45,3500,'',1,'2026-01-11 14:28:17'),
(3,'Tratamento Facial','Limpeza e hidrata├º├úo profunda.',50,4000,'',1,'2026-01-11 14:28:17'),
(4,'Pedicure Spa','Tratamento completo aos p├®s.',50,3900,NULL,0,'2026-01-11 17:56:54'),
(5,'Pedicure Spa','Tratamento completo aos p├®s.',50,3900,NULL,0,'2026-01-11 23:36:42'),
(6,'Pedras Quentes',NULL,60,4500,NULL,1,'2026-01-12 18:45:35'),
(7,'Massagem T├óntrica',NULL,40,6000,NULL,1,'2026-01-13 14:55:01');
/*!40000 ALTER TABLE `services` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL,
  `email` varchar(190) NOT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('CLIENT','ADMIN') NOT NULL DEFAULT 'CLIENT',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `users` VALUES
(1,'Admin','admin@relaxzone.pt','910000000','$2b$10$ePB5.v6ro/T3YfJh5vZWpO6EEZ/XIb9ZYTpWs76EBzddNKKFCmJRK','ADMIN',1,'2026-01-11 14:38:36'),
(2,'Utilizador Normal','user1@relaxzone.pt',NULL,'$2b$10$2z8sNFARnZNW8A4BirlSg.X8/6MUzAZkz3IEFIYWw.TpGWN6FLu5O','CLIENT',1,'2026-01-11 22:26:25'),
(3,'Utilizador Normal','user2@relaxzone.pt',NULL,'$2b$10$IlIj7Xqzc5NECUBlWyCIPOoIoe.utdghTBgSyT.XKGZLRSTtr1KTC','CLIENT',1,'2026-01-11 22:42:00'),
(4,'Jo├úo Morgado','JoaoMorg@gmail.com',NULL,'$2b$10$GG00ZJPPvfA7HKt6guugaeXJNgA8CIa.m0wqhB4YvA2UWdyIYbPP6','CLIENT',1,'2026-01-12 22:13:00');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping events for database 'relax_zone'
--

--
-- Dumping routines for database 'relax_zone'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-01-13 20:13:38
